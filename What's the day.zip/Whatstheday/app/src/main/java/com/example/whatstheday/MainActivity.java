package com.example.whatstheday;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Random;


/**
 * This is a quiz app on finding the correct day for given date.
 */
@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class MainActivity extends AppCompatActivity {

    int Score = 0;
    String correctDay;
    String CorrectDateAndDayAfterQuiz;


    /**
     * Creates dates and options during app start.
     * @param savedInstanceState
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DateAndOptions();

    }


    /**
     * Displays a random date for TextView.
     * Displays non recursive options of days for the random date.
     */

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void DateAndOptions() {

        LocalDate randomDate1 = RandomDate();
        String RDATE = randomDate1.toString();

        displayMessage(RDATE);

        DayOfWeek correctday = randomDate1.getDayOfWeek();
        correctDay = correctday.toString();

        CreateOptions(correctDay);

        CorrectDateAndDayAfterQuiz = "DATE: " + RDATE + "\n DAY: " + correctDay;

        LocalDate randomDate2 = RandomDate();
        DayOfWeek wrongday1 = randomDate2.getDayOfWeek();
        String wrongDay1 = wrongday1.toString();
        while (wrongDay1.equals(correctDay)) {
            randomDate2 = RandomDate();
            wrongday1 = randomDate2.getDayOfWeek();
            wrongDay1 = wrongday1.toString();
        }
        CreateOptions(wrongDay1);

        LocalDate randomDate3 = RandomDate();
        DayOfWeek wrongday2 = randomDate3.getDayOfWeek();
        String wrongDay2 = wrongday2.toString();
        while (wrongDay2.equals(correctDay) || wrongDay2.equals(wrongDay1)) {
            randomDate3 = RandomDate();
            wrongday2 = randomDate3.getDayOfWeek();
            wrongDay2 = wrongday2.toString();
        }
        CreateOptions(wrongDay2);

        LocalDate randomDate4 = RandomDate();
        DayOfWeek wrongday3 = randomDate4.getDayOfWeek();
        String wrongDay3 = wrongday3.toString();
        while (wrongDay3.equals(correctDay) || wrongDay3.equals(wrongDay1)
                || wrongDay3.equals(wrongDay2)) {
            randomDate4 = RandomDate();
            wrongday3 = randomDate4.getDayOfWeek();
            wrongDay3 = wrongday3.toString();
        }

        CreateOptions(wrongDay3);

    }


    /**
     * Finds a random date.
     * @return RDATE
     */

    @RequiresApi(api = Build.VERSION_CODES.O)
    public LocalDate RandomDate() {

        LocalDate today = LocalDate.now();
        String s = today.toString();
        CharSequence cs = s;

        LocalDate localDate = LocalDate.parse(cs);
        int numberOfDays = Math.toIntExact(localDate.toEpochDay());

        Random n = new Random();
        int low = -3650;
        int high = numberOfDays;
        int result = n.nextInt(high-low) + low;

        LocalDate randomDate = LocalDate.ofEpochDay(result);

        return randomDate;

    }


    /**
     * Shuffles and creates options.
     */

    public void CreateOptions(String GivenDay) {
        int NumberForOption = RandomNumbers();


        RadioButton Text1 = (RadioButton) findViewById(R.id.Day_1);
        String TextDay1 = (Text1.getText().toString());
        RadioButton Text2 = (RadioButton) findViewById(R.id.Day_2);
        String TextDay2 = Text2.getText().toString();
        RadioButton Text3 = (RadioButton) findViewById(R.id.Day_3);
        String TextDay3 = Text3.getText().toString();
        RadioButton Text4 = (RadioButton) findViewById(R.id.Day_4);
        String TextDay4 = Text4.getText().toString();

        if (NumberForOption == 1 && TextDay1.equals("a")) {
            TextView DaysText1View = (TextView) findViewById(R.id.Day_1);
            DaysText1View.setText(GivenDay);
        } else if (NumberForOption == 2 && TextDay2.equals("a")) {
            TextView Days2TextView = (TextView) findViewById(R.id.Day_2);
            Days2TextView.setText(GivenDay);
        } else if (NumberForOption == 3 && TextDay3.equals("a")) {
        TextView Days3TextView = (TextView) findViewById(R.id.Day_3);
        Days3TextView.setText(GivenDay);
        } else if (NumberForOption == 4 && TextDay4.equals("a")) {
        TextView Days4TextView = (TextView) findViewById(R.id.Day_4);
        Days4TextView.setText(GivenDay);
        } else {
        CreateOptions(GivenDay);
        }

        }


    /**
     * Gives 4 random numbers between 1 and 4.
     */

    public int RandomNumbers() {

        Random numInRange1To4 = new Random();
        int low = 1;
        int high = 5;
        int result = numInRange1To4.nextInt(high-low) + low;
        return result;

    }


    /**
     * This method is called when submit button is clicked.
     *
     * Checks if answer is right or wrong.
     * If right continues the quiz.
     * If wrong terminates the quiz, displays score and gives option to try again.
     */

    @SuppressLint("SetTextI18n")
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void submit (View v) {

        RadioGroup options = (RadioGroup) findViewById(R.id.Options);
        int SelectedOption = options.getCheckedRadioButtonId();
        if(SelectedOption == -1){
            Context context = getApplicationContext();
            CharSequence text = "Choose an option";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();

        } else {
            RadioButton SelectedRadioButton = (RadioButton) findViewById(SelectedOption);
            String ChoosenOption = SelectedRadioButton.getText().toString();

            if (ChoosenOption == correctDay) {
                Score = Score + 1;
                displayScore(Score);
                defaults();
                DateAndOptions();

            } else {
                LinearLayout DuringGame = (LinearLayout) findViewById(R.id.DuringGame);
                DuringGame.setVisibility(View.GONE);

                LinearLayout AfterGame = (LinearLayout) findViewById(R.id.AfterGame);
                AfterGame.setVisibility(View.VISIBLE);
                TextView AfterGameTextView = (TextView) findViewById(R.id.ScoreAfterGame);
                AfterGameTextView.setText("SCORE: " + Score);
                TextView CorrectAnswerAfterGameTextView = (TextView) findViewById(R.id.CorrectAnswerDisplayAfterGame);
                CorrectAnswerAfterGameTextView.setText(CorrectDateAndDayAfterQuiz);
            }
        }

    }


    /**
     * This method displays random date on the screen.
     */
    private void displayMessage(String message) {

        TextView dateTextView = (TextView) findViewById(R.id.date_view);
        dateTextView.setText(message);

    }


    /**
     * This method displays score on the screen during game.
     */
    private void displayScore(int num) {

        TextView scoreTextView = (TextView) findViewById(R.id.Score);
        scoreTextView.setText("SCORE: " + num +"\n" + "Treat eppa Da?!");

    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    public void TryAgain (View v) {

        TextView scoreTextView = (TextView) findViewById(R.id.Score);
        scoreTextView.setText("");
        defaults();
        Score = 0;
        DateAndOptions();

        LinearLayout DuringGame = (LinearLayout) findViewById(R.id.DuringGame);
        DuringGame.setVisibility(View.VISIBLE);

        LinearLayout AfterGame = (LinearLayout) findViewById(R.id.AfterGame);
        AfterGame.setVisibility(View.GONE);

    }


    /**
     * Sets back original value to all text views.
     */
    public void defaults() {

        TextView DaysText1View = (TextView) findViewById(R.id.Day_1);
        DaysText1View.setText("a");
        TextView DaysText2View = (TextView) findViewById(R.id.Day_2);
        DaysText2View.setText("a");
        TextView DaysText3View = (TextView) findViewById(R.id.Day_3);
        DaysText3View.setText("a");
        TextView DaysText4View = (TextView) findViewById(R.id.Day_4);
        DaysText4View.setText("a");

    }
    }






